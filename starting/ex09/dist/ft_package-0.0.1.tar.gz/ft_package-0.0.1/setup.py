from setuptools import setup,find_packages

setup(
    name="ft_package",
    version="0.0.1",
    author="gmorange",
    author_email="gmorange@student.42.fr",
    description="a sample test package",
    packages=find_packages(),
)
